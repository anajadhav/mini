package com.example.ana.mini;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class age extends AppCompatActivity {
    RadioGroup r1;
    RadioButton rb1,rb2,rb3;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age);

        r1=(RadioGroup)findViewById(R.id.radioage);

        rb1=(RadioButton)findViewById(R.id.age1);
        rb2=(RadioButton)findViewById(R.id.age2);
        rb3=(RadioButton)findViewById(R.id.age3);

        b1=(Button)findViewById(R.id.next);



        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                int selectedId = r1.getCheckedRadioButtonId();

                rb1 = (RadioButton) findViewById(selectedId);
                rb2 = (RadioButton) findViewById(selectedId);
                rb3= (RadioButton) findViewById(selectedId);

                if(r1.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(age.this, "age is not selected", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    startActivity(new Intent(getApplicationContext(), age.class));
                }

                   if(rb1.isChecked()){

                        startActivity(new Intent(getApplicationContext(), test.class));
                    }else if(rb2.isChecked()){

                        startActivity(new Intent(getApplicationContext(), test1.class));
                    }
                   else if(rb3.isChecked()){

                       startActivity(new Intent(getApplicationContext(), test2.class));
                   }
                       else
                    {
                        Toast.makeText(age.this, "incorrect", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), age.class));
                    }
                }

        });
    }
}
