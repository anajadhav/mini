package com.example.ana.mini;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Credentials;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    Button b1, b2;
    EditText e1, e2, e3;
    TextView t1, t2, t3;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.login);
        b2 = (Button) findViewById(R.id.signup);
        e1 = (EditText) findViewById(R.id.username);
        e2 = (EditText) findViewById(R.id.password);
        e3 = (EditText) findViewById(R.id.emailid);
        t1 = (TextView) findViewById(R.id.user);
        t2 = (TextView) findViewById(R.id.pass);
        t3 = (TextView) findViewById(R.id.email);

        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

         /*   String s=e1.getText().toString();
            String s1=e2.getText().toString();
            String s2=e3.getText().toString();

               if (e1.getText().toString().equals(s) &&
                        e2.getText().toString().equals(s1)
                        && e3.getText().toString().equals(s2))*/


                    //         Intent i=new Intent(MainActivity.this,login1.class);
                    //       startActivity(i);
                    /*startActivity(new Intent(getApplicationContext(),login.class));*/
                    //     Toast.makeText(getApplicationContext(),
                    //           "login successfull", Toast.LENGTH_SHORT).show();
                 /*else {
                    Toast.makeText(getApplicationContext(), "Wrong Credentials ", Toast.LENGTH_SHORT).show();
                }*/

                    validate(e3.getText().toString(),e2.getText().toString());
                }
        });


                b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),signup.class));
            }
        });

    }
    private void validate(String username, String userpassword)
    {
        progressDialog.setMessage("login to the app");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(username,userpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    progressDialog.dismiss();
                    Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this,login1.class));
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Login Failed",Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}

