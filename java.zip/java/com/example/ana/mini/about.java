package com.example.ana.mini;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.view.View;
import android.widget.Toast;

public class about extends AppCompatActivity {

    private RadioGroup r1,r2;
    private RadioButton rb1, rb2, rb3, rb4;
    private Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        //addListenerOnButton();

        r1=(RadioGroup)findViewById(R.id.radiogen);

        r2=(RadioGroup)findViewById(R.id.radiooccu);

        //r3=(RadioGroup)findViewById(R.id.radiooccu);


        rb1 = (RadioButton) findViewById(R.id.male);
        rb2 = (RadioButton) findViewById(R.id.female);
        rb3 = (RadioButton) findViewById(R.id.lit);
        rb4 = (RadioButton) findViewById(R.id.illit);
        /*rb5 = (RadioButton) findViewById(R.id.female);
        rb6 = (RadioButton) findViewById(R.id.lit);
        rb7 = (RadioButton) findViewById(R.id.illit);*/

        b1 = (Button) findViewById(R.id.next);



        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // get selected radio button from radioGroup
                int selectedId = r1.getCheckedRadioButtonId();
                int selectedId1 = r2.getCheckedRadioButtonId();
                //int selectedId2 = r3.getCheckedRadioButtonId();



                rb1 = (RadioButton) findViewById(selectedId);

                rb2 = (RadioButton) findViewById(selectedId);

                rb3= (RadioButton) findViewById(selectedId1);

                rb4= (RadioButton) findViewById(selectedId1);

                if(r1.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(about.this, "gender is not selected", Toast.LENGTH_SHORT).show();
                }
                else if(r2.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(about.this, "occupation is not selected", Toast.LENGTH_SHORT).show();
                }

                else {
                    Toast.makeText(about.this,
                            rb1.getText(), Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(getApplicationContext(), age.class));

                }
            }

        });


    }
}
